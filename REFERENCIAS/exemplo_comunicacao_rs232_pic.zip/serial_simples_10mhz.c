#include <16f877.h>         // identifica microcontrolador alvo
#use delay (clock=10000000)  // <- define cristal para 10Mhz. Para outros valores, mude e recompile.
#include <cuscostdio.h>     // inclui biblioteca de fun��es do projeto CUSCOPiC
#use  RS232(baud=9600, parity=N, bits=8, xmit=PIN_C6,rcv=PIN_C7) // configura serial
 // serial configurada para velocidade de 9600 bps
 // sem paridade, 8 bits
 
 /*
 Objetivo do programa:
 Quando D0 mudar de estado, ser� enviada mensagem para o terminal.
 Quando for recebido do terminal os valores 1 e 2, liga os rel�s (E0 e E1).
 Quando for recebido do terminal os valores 3 e 4, desliga os rel�s (E0 e E1).
 */


void main()       // fun��o principal
  {
  char x;
  short vlr_d0_ant = 1;
  while(1) // la�o infinito
    {
    printf("\n\rCUSCOPIC\n\r");
    while(1)
      {
      if (kbhit())          // se houver caractere no buffer de entrada da serial ...
         {
         x = getchar();   // busca caractere da serial
         switch(x)  // escolhe x
           {
           case '1' : output_high(PIN_E0); break;
           case '2' : output_low (PIN_E0); break;
           case '3' : output_high(PIN_E1); break;
           case '4' : output_low (PIN_E1); break;
           }
         }
      if (input(PIN_D0) != vlr_d0_ant)  // SE ESTADO DO PINO MUDOU ...
         {
         if (input(PIN_D0)) printf("\n\rD0 ativado.");  // MANDA MENSAGEM 
         else               printf("\n\rD0 desativado.");
         vlr_d0_ant = input(PIN_D0);  // REGISTRA NOVO ESTADO DO PINO
         }
      }
    }
  }
  
